from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Quiz questions and answers
questions = [
    {"question": "What does CPU stand for?", "answer": "central processing unit"},
    {"question": "What does GPU stand for?", "answer": "graphics processing unit"},
    {"question": "What does RAM stand for?", "answer": "random access memory"},
    {"question": "What does PSU stand for?", "answer": "power supply"},
    {"question": "What does BIOS stand for?", "answer": "basic input/output system"},
    {"question": "What does USB stand for?", "answer": "universal serial bus"},
    {"question": "What does IP stand for?", "answer": "internet protocol"},
    {"question": "What does HTML stand for?", "answer": "hypertext markup language"},
    {"question": "What does LAN stand for?", "answer": "local area network"},
    {"question": "What does WAN stand for?", "answer": "wide area network"},
    {"question": "What does URL stand for?", "answer": "uniform resource locator"},
    {"question": "What does CSS stand for?", "answer": "cascading style sheets"},
    {"question": "What does SSL stand for?", "answer": "secure sockets layer"},
    {"question": "What does VPN stand for?", "answer": "virtual private network"},
    {"question": "What does DNS stand for?", "answer": "domain name system"},
    {"question": "What does ISP stand for?", "answer": "internet service provider"},
    {"question": "What does JPEG stand for?", "answer": "joint photographic experts group"},
    {"question": "What does PDF stand for?", "answer": "portable document format"},
    {"question": "What does GIF stand for?", "answer": "graphics interchange format"},
    {"question": "What does HTTP stand for?", "answer": "hypertext transfer protocol"}
]

@app.route('/')
def index():
    return render_template('index.html', questions=questions)

@app.route('/check_answer', methods=['POST'])
def check_answer():
    data = request.json
    question_index = data['question_index']
    user_answer = data['user_answer'].strip().lower()
    correct_answer = questions[question_index]['answer'].lower()
    is_correct = user_answer == correct_answer
    return jsonify({'is_correct': is_correct, 'correct_answer': correct_answer})

if __name__ == '__main__':
    app.run(debug=True)
